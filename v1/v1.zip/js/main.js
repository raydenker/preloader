const preloader = document.querySelector('.preloader')
setTimeout(() => {
    preloader.classList.add('hide')
}, 3000);